# LIFORA — Unified Emergency Response and Resource Coordination System

> **Solution Statement:**  
> LIFORA is a centralized software platform designed to improve emergency response by connecting citizens, hospitals, ambulances, police, firefighters, blood banks, and rescue teams through a shared coordination system. The platform operates autonomously to bridge critical shortages across healthcare facilities and provides citizens with a direct multi-agency dispatch channel.

---

## 🎬 Kinetic Typography Entrance & Dual Portals

### 1. 3D Kinetic Typography Entrance
- **Dynamic Letter-by-Letter Stagger:** Clicking the **LIFORA** brand logo triggers a staggered 3D kinetic animation of **`L - I - F - O - R - A`** with radiant color shifting (`#38bdf8` to `#a78bfa` to `#f43f5e`), fluid spring physics, harmonic chord audio synthesis, and smooth blur-to-sharp reveals.
- **Interactive Letter Physics:** Hovering over individual letters tilts and lifts them dynamically with luminous glow halos.

### 2. The Two Portals
Directly underneath the kinetic typography, two Canva-grade glassmorphic portal cards are revealed:
1. **👥 Citizen Portal (Public Sector Hub):**
   - Streamlined top-pinned incident reporting interface with zero lag or scrolling down.
   - **Multi-Agency Live Response Board**: Instantly triggers live status updates across 4 responding agencies (Trauma Hospital, Paramedic EMS, Highway Police Green Wave, Fire Rescue Squad).
   - Strict Portal Isolation: Submitting an incident keeps the citizen firmly inside the Citizen Portal with visual confirmation and active pulse indicators.
   - GPS telemetry location picker and immediate Ticket LF registration.

2. **🏢 Organization Portal (Multi-Agency Command Center & Autonomous Hub):**
   - **100% Autonomous Inter-Organization Mutual Aid (Zero Manual Input)**:
     - Real-time IoT/CAD telemetry detects hospital shortages (O- blood deficits, 100% ICU bed saturation, low liquid oxygen manifolds).
     - The engine automatically calculates the nearest capable donor facility with surplus.
     - Automatically generates and sends an encrypted CAD emergency assistance report to the neighbor organization without requiring human typing or manual forms.
     - Displays inbound neighbor confirmation and automated courier dispatch.
     - 5-stage live progress tracking with Police Green Corridor escort coordination.
   - **Live Crisis Simulation Engine**: 1-click test button (`⚡ Simulate Sudden Hospital Shortage`) to watch autonomous detection, neighbor matching, and mutual aid dispatch live.
   - GIS Tactical Leaflet Map with layer filters (Hospitals, Ambulances, Fire, Blood, Incidents).
   - Smart Unit Matching and Resource Reliability Freshness Auditor.

---

## 📁 Project Files & Structure

| File | Description | Link |
|---|---|---|
| `index.html` | Complete single-page application structure, kinetic entrance, dual portals, and layout | [index.html](file:///C:/Users/Lenovo/.gemini/antigravity-ide/scratch/lifegrid-emergency-system/index.html) |
| `style.css` | Complete Canva-grade CSS design system, glassmorphism, wave animations, and responsive styles | [style.css](file:///C:/Users/Lenovo/.gemini/antigravity-ide/scratch/lifegrid-emergency-system/style.css) |
| `app.js` | Full application logic, Web Audio synthesizer, Leaflet map engine, autonomous mutual aid telemetry, and portal state management | [app.js](file:///C:/Users/Lenovo/.gemini/antigravity-ide/scratch/lifegrid-emergency-system/app.js) |
| `data.js` | Comprehensive dataset: hospitals, blood banks, ICU beds, oxygen supplies, ambulances, and autonomous CAD shortage reports | [data.js](file:///C:/Users/Lenovo/.gemini/antigravity-ide/scratch/lifegrid-emergency-system/data.js) |
| `lifora-emergency-system.zip` | Complete pre-packaged ZIP archive containing all project files for 1-click download/sharing | [lifora-emergency-system.zip](file:///C:/Users/Lenovo/.gemini/antigravity-ide/scratch/lifegrid-emergency-system/lifora-emergency-system.zip) |

---

## 🚀 Running the Platform

1. **Local Dev Server:**
   ```powershell
   python -m http.server 8085 --directory "C:\Users\Lenovo\.gemini\antigravity-ide\scratch\lifegrid-emergency-system"
   ```
2. **Access in Browser:**
   Open: [http://localhost:8085/index.html](http://localhost:8085/index.html)
3. **Download ZIP Archive Directly:**
   Open: [http://localhost:8085/lifora-emergency-system.zip](http://localhost:8085/lifora-emergency-system.zip)

