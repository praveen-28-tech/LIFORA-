/**
 * LIFORA - Unified Emergency Response and Resource Coordination System
 * Pre-populated realistic operational data for Metropolitan Emergency Grid
 */

const LIFORA_DATA = {
  // Center coordinates: Metropolitan Area (e.g., Metro Center)
  mapCenter: [28.6139, 77.2090], // Coordinates centered on major metro hub
  defaultZoom: 13,

  // Hospitals & Trauma Centers
  hospitals: [
    {
      id: "HOSP-01",
      name: "Apex Central Trauma & Multi-Specialty Hospital",
      type: "Level 1 Trauma Center",
      address: "Ring Road Sector 4, Metro Central",
      lat: 28.6250,
      lng: 77.2150,
      phone: "+1 (800) 555-0191",
      directEmergency: "ext. 911 / 102",
      icuBeds: 14,
      totalIcuBeds: 20,
      generalBeds: 42,
      totalGeneralBeds: 120,
      ventilators: 8,
      oxygenAvailable: true,
      bloodBankOnSite: true,
      traumaTeamOnDuty: true,
      lastVerifiedMinutesAgo: 4,
      verifiedBy: "Dr. A. Verma (Charge Nurse / ER Triage)",
      reliabilityScore: 99,
      status: "Operational"
    },
    {
      id: "HOSP-02",
      name: "Metro General & Cardiac Care Institute",
      type: "Specialized Cardiac & Emergency Care",
      address: "North Boulevard, Block B",
      lat: 28.6400,
      lng: 77.2280,
      phone: "+1 (800) 555-0242",
      directEmergency: "ext. 404 / 108",
      icuBeds: 5,
      totalIcuBeds: 16,
      generalBeds: 18,
      totalGeneralBeds: 80,
      ventilators: 4,
      oxygenAvailable: true,
      bloodBankOnSite: true,
      traumaTeamOnDuty: true,
      lastVerifiedMinutesAgo: 12,
      verifiedBy: "EMS Telemetry Gateway v4.1",
      reliabilityScore: 95,
      status: "Operational"
    },
    {
      id: "HOSP-03",
      name: "St. Jude Children & Maternity Emergency Center",
      type: "Pediatric & Maternal Emergency",
      address: "East Avenue, Parkview",
      lat: 28.5980,
      lng: 77.2350,
      phone: "+1 (800) 555-0378",
      directEmergency: "ext. 108 / 112",
      icuBeds: 2,
      totalIcuBeds: 10,
      generalBeds: 9,
      totalGeneralBeds: 50,
      ventilators: 2,
      oxygenAvailable: true,
      bloodBankOnSite: false,
      traumaTeamOnDuty: true,
      lastVerifiedMinutesAgo: 48, // Stale warning demonstration!
      verifiedBy: "Hospital Ops Admin (Pending re-sync)",
      reliabilityScore: 78,
      status: "High Capacity Alert"
    },
    {
      id: "HOSP-04",
      name: "Westside Community Emergency Clinic",
      type: "Urgent Care & Secondary Triage",
      address: "Civil Lines, Westway",
      lat: 28.6180,
      lng: 77.1850,
      phone: "+1 (800) 555-0489",
      directEmergency: "ext. 102",
      icuBeds: 0,
      totalIcuBeds: 4,
      generalBeds: 28,
      totalGeneralBeds: 40,
      ventilators: 1,
      oxygenAvailable: true,
      bloodBankOnSite: false,
      traumaTeamOnDuty: false,
      lastVerifiedMinutesAgo: 8,
      verifiedBy: "Nurse Coordinator R. Davis",
      reliabilityScore: 94,
      status: "Operational"
    },
    {
      id: "HOSP-05",
      name: "South Suburban Emergency & Burn Care Center",
      type: "Burn & Specialized Surgical Response",
      address: "South Ring Highway, Gate 3",
      lat: 28.5800,
      lng: 77.2000,
      phone: "+1 (800) 555-0552",
      directEmergency: "ext. 991",
      icuBeds: 7,
      totalIcuBeds: 12,
      generalBeds: 35,
      totalGeneralBeds: 90,
      ventilators: 6,
      oxygenAvailable: true,
      bloodBankOnSite: true,
      traumaTeamOnDuty: true,
      lastVerifiedMinutesAgo: 62, // Outdated!
      verifiedBy: "Automatic API Sync (Timed out)",
      reliabilityScore: 68,
      status: "Verification Overdue"
    }
  ],

  // Emergency Ambulances (Live fleet)
  ambulances: [
    {
      id: "AMB-101",
      callSign: "Medic-Alpha 1",
      type: "ACLS (Advanced Cardiac Life Support)",
      baseStation: "Apex Central Trauma",
      lat: 28.6210,
      lng: 77.2180,
      status: "Available", // Available, En Route, On Scene, Maintenance
      crew: "2 Paramedics, 1 EMT-P (Dr. Sen & EMT Ortiz)",
      equipment: ["Defibrillator", "Ventilator", "Oxygen Kit", "ECG Telemetry", "Pediatric Trauma Pack"],
      etaMinutes: 3,
      fuelPct: 88,
      lastHeartbeatSec: 10,
      reliabilityScore: 99,
      contact: "+1 (800) 555-AMB1"
    },
    {
      id: "AMB-102",
      callSign: "Medic-Bravo 4",
      type: "ACLS (Advanced Life Support)",
      baseStation: "Metro General",
      lat: 28.6360,
      lng: 77.2250,
      status: "En Route",
      incidentAssigned: "INC-8941",
      crew: "1 Paramedic, 1 Driver-EMT (EMT Brooks)",
      equipment: ["Defibrillator", "Oxygen Kit", "ECG Monitor", "Spine Board"],
      etaMinutes: 6,
      fuelPct: 74,
      lastHeartbeatSec: 25,
      reliabilityScore: 98,
      contact: "+1 (800) 555-AMB4"
    },
    {
      id: "AMB-103",
      callSign: "Rapid-Rescue 7",
      type: "BLS (Basic Life Support Ambulance)",
      baseStation: "Westside Clinic",
      lat: 28.6140,
      lng: 77.1910,
      status: "Available",
      crew: "2 EMT-Basics",
      equipment: ["Oxygen Tank", "Suction Unit", "First-Aid Kit", "Stretcher"],
      etaMinutes: 4,
      fuelPct: 92,
      lastHeartbeatSec: 15,
      reliabilityScore: 96,
      contact: "+1 (800) 555-AMB7"
    },
    {
      id: "AMB-104",
      callSign: "Neonatal-Care 2",
      type: "MICU / Pediatric Transport",
      baseStation: "St. Jude Children",
      lat: 28.6010,
      lng: 77.2320,
      status: "Available",
      crew: "Pediatric Specialist Nurse & EMT",
      equipment: ["Infant Incubator", "Pediatric Ventilator", "Infusion Pumps"],
      etaMinutes: 8,
      fuelPct: 81,
      lastHeartbeatSec: 32,
      reliabilityScore: 95,
      contact: "+1 (800) 555-AMBN"
    },
    {
      id: "AMB-105",
      callSign: "Medic-Delta 9",
      type: "ACLS Heavy Rescue",
      baseStation: "South Suburban",
      lat: 28.5850,
      lng: 77.1950,
      status: "Available",
      crew: "2 Critical Care Paramedics",
      equipment: ["Cardiac Monitor", "Trauma Surgical Kit", "Ventilator", "Oxygen"],
      etaMinutes: 7,
      fuelPct: 65,
      lastHeartbeatSec: 40,
      reliabilityScore: 93,
      contact: "+1 (800) 555-AMBD"
    }
  ],

  // Fire & Rescue Stations
  fireStations: [
    {
      id: "FIRE-01",
      name: "Central Fire & Hazmat Station 1",
      lat: 28.6290,
      lng: 77.2050,
      phone: "+1 (800) 555-FIRE1",
      enginesAvailable: 3,
      totalEngines: 4,
      ladderTrucks: 2,
      hazmatTeamReady: true,
      waterTenders: 2,
      lastVerifiedMinutesAgo: 6,
      reliabilityScore: 98,
      status: "Ready"
    },
    {
      id: "FIRE-02",
      name: "East River Rescue & Marine Squad Station 5",
      lat: 28.6050,
      lng: 77.2420,
      phone: "+1 (800) 555-FIRE5",
      enginesAvailable: 2,
      totalEngines: 3,
      ladderTrucks: 1,
      hazmatTeamReady: false,
      rescueBoats: 3,
      lastVerifiedMinutesAgo: 15,
      reliabilityScore: 94,
      status: "Ready"
    },
    {
      id: "FIRE-03",
      name: "West Industrial District Fire Station 9",
      lat: 28.6220,
      lng: 77.1750,
      phone: "+1 (800) 555-FIRE9",
      enginesAvailable: 1,
      totalEngines: 3,
      ladderTrucks: 2,
      hazmatTeamReady: true,
      lastVerifiedMinutesAgo: 55, // Stale
      reliabilityScore: 75,
      status: "Overdue Audit"
    }
  ],

  // Police & Rapid Enforcement
  policeUnits: [
    {
      id: "POL-01",
      callSign: "Highway Patrol Sector 3",
      type: "Rapid Response Interceptor",
      lat: 28.6170,
      lng: 77.2110,
      status: "Patrolling",
      officers: 2,
      equipment: ["Emergency First-Aid Kit", "AED", "Tactical Barrier"],
      etaMinutes: 2,
      reliabilityScore: 99
    },
    {
      id: "POL-02",
      callSign: "Metro North Squad Car 12",
      type: "Patrol & Crowd Control",
      lat: 28.6330,
      lng: 77.2200,
      status: "Assigned",
      incidentAssigned: "INC-8941",
      officers: 2,
      equipment: ["AED", "First-Aid Kit"],
      etaMinutes: 4,
      reliabilityScore: 97
    },
    {
      id: "POL-03",
      callSign: "Suburban Security Unit 8",
      type: "Specialized Incident Control",
      lat: 28.5910,
      lng: 77.2080,
      status: "Standby",
      officers: 3,
      equipment: ["Tactical Rescue Kit", "AED"],
      etaMinutes: 5,
      reliabilityScore: 95
    }
  ],

  // Blood Banks with inventory
  bloodBanks: [
    {
      id: "BLD-01",
      name: "Red Cross Metro Regional Blood Bank",
      address: "Near Central Metro Gate 2",
      lat: 28.6235,
      lng: 77.2130,
      phone: "+1 (800) 555-BLD1",
      inventory: {
        "O+": 34,
        "O-": 4, // Critical shortage
        "A+": 28,
        "A-": 8,
        "B+": 32,
        "B-": 11,
        "AB+": 16,
        "AB-": 3,
        "Platelets": 22
      },
      emergencyDispatchReady: true,
      lastVerifiedMinutesAgo: 10,
      verifiedBy: "Dr. K. Nair, Blood Bank Officer",
      reliabilityScore: 97,
      status: "Operational • O- Critical Shortage"
    },
    {
      id: "BLD-02",
      name: "Apex Hospital Clinical Blood Repository",
      address: "Inside Apex Central Hospital complex",
      lat: 28.6248,
      lng: 77.2155,
      phone: "+1 (800) 555-BLD2",
      inventory: {
        "O+": 18,
        "O-": 1, // Extremely low
        "A+": 15,
        "A-": 4,
        "B+": 20,
        "B-": 6,
        "AB+": 9,
        "AB-": 2,
        "Platelets": 14
      },
      emergencyDispatchReady: true,
      lastVerifiedMinutesAgo: 2,
      verifiedBy: "Automated RFID Fridge Monitor",
      reliabilityScore: 100,
      status: "Operational • RFID Verified"
    },
    {
      id: "BLD-03",
      name: "LifeStream Community Blood Center East",
      address: "East Ring Crossing, Suite 100",
      lat: 28.6020,
      lng: 77.2380,
      phone: "+1 (800) 555-BLD3",
      inventory: {
        "O+": 22,
        "O-": 6,
        "A+": 19,
        "A-": 7,
        "B+": 25,
        "B-": 9,
        "AB+": 12,
        "AB-": 4,
        "Platelets": 10
      },
      emergencyDispatchReady: true,
      lastVerifiedMinutesAgo: 75, // Stale warning!
      verifiedBy: "Manual Log Book (Pending electronic sync)",
      reliabilityScore: 64,
      status: "Verification Overdue"
    }
  ],

  // Active Emergency Incidents (Demonstrating Unified Coordination)
  incidents: [
    {
      id: "INC-8941",
      type: "Medical / Road Collision",
      category: "medical",
      title: "Multi-Vehicle Traffic Accident at Central Interchange",
      location: "Intersection of Ring Road & Mall Highway",
      lat: 28.6310,
      lng: 77.2220,
      severity: "CRITICAL", // CRITICAL, HIGH, MODERATE, LOW
      reportedTime: "8 mins ago",
      timestamp: Date.now() - 8 * 60 * 1000,
      reporter: "Citizen John D. (+1 555-7721)",
      victims: 3,
      description: "Two cars collided at high speed. One trapped driver with severe chest trauma and hemorrhage. Conscious but unstable.",
      requiredResources: ["ACLS Ambulance", "Fire Extrication Tool", "Police Traffic Diversion", "O- Blood Reserve"],
      assignedUnits: [
        { id: "AMB-102", name: "Medic-Bravo 4", type: "ACLS Ambulance", status: "En Route (ETA 3 mins)" },
        { id: "POL-02", name: "Metro North Squad Car 12", type: "Police Interceptor", status: "On Scene" }
      ],
      unfulfilledNeeds: ["Hydraulic Cutter / Fire Engine Support for trapped victim"],
      status: "DISPATCHED", // REPORTED, MATCHING, DISPATCHED, ON_SCENE, RESOLVED
      matchedHospital: "Apex Central Trauma & Multi-Specialty Hospital (Distance: 1.4 km, 14 ICU Beds)",
      citizenProgress: 60, // 20: Reported, 40: Matched, 60: Dispatched, 80: En Route, 100: On Scene
      connectedAgencies: [
        {
          id: "AGY-HOSP",
          type: "Trauma Hospital",
          name: "Apex Central Trauma & Multi-Specialty Hospital",
          role: "ER Triage & Trauma Bay Standby",
          status: "ACKNOWLEDGED",
          actionTaken: "Trauma Bay #3 prepped, blood transfusion unit standing by",
          eta: "Ready on Arrival",
          icon: "🏥",
          phone: "+1 (800) 555-0191"
        },
        {
          id: "AGY-EMS",
          type: "Paramedic EMS",
          name: "Medic-Bravo 4 (ACLS Unit)",
          role: "Advanced Life Support & Extrication Transport",
          status: "EN_ROUTE",
          actionTaken: "En route with chest decompression kit and ECG telemetry",
          eta: "3 mins (1.1 km)",
          icon: "🚑",
          phone: "+1 (800) 555-AMB4"
        },
        {
          id: "AGY-POL",
          type: "Highway Police",
          name: "Metro North Squad Car 12",
          role: "Intersection Green Corridor & Perimeter Control",
          status: "ON_SCENE",
          actionTaken: "Blocked east lane to ensure ambulance fast approach corridor",
          eta: "On Scene",
          icon: "🚓",
          phone: "+1 (800) 555-100"
        },
        {
          id: "AGY-FIRE",
          type: "Fire Rescue",
          name: "Central Fire Squad 1",
          role: "Hydraulic Jaws Extrication for Trapped Passenger",
          status: "DISPATCHED",
          actionTaken: "Heavy rescue truck en route with hydraulic cutters",
          eta: "4 mins (1.8 km)",
          icon: "🚒",
          phone: "+1 (800) 555-FIRE1"
        }
      ]
    },
    {
      id: "INC-8942",
      type: "Fire / Structural Hazard",
      category: "fire",
      title: "Electrical Fire with Dense Smoke in Commercial Complex",
      location: "Civic Plaza Tower, 3rd Floor, Westway",
      lat: 28.6215,
      lng: 77.1890,
      severity: "HIGH",
      reportedTime: "15 mins ago",
      timestamp: Date.now() - 15 * 60 * 1000,
      reporter: "Building Security Mgr S. Mehta (+1 555-8832)",
      victims: 0,
      description: "Electrical switchboard fire spreading to false ceiling. Sprinklers active, occupants evacuating via stairwells. Smoke inhalation risk.",
      requiredResources: ["Fire Engine x2", "Ladder Truck", "BLS Standby Ambulance"],
      assignedUnits: [
        { id: "FIRE-01", name: "Central Fire Engine 1", type: "Fire Engine", status: "On Scene" },
        { id: "AMB-103", name: "Rapid-Rescue 7", type: "BLS Ambulance", status: "Standby Perimeter" }
      ],
      unfulfilledNeeds: [],
      status: "ON_SCENE",
      matchedHospital: "Westside Community Emergency Clinic",
      citizenProgress: 85
    },
    {
      id: "INC-8943",
      type: "Blood Urgency / Rare Group",
      category: "blood",
      title: "Urgent O-Negative Blood Request for Pediatric Surgery",
      location: "St. Jude Children Hospital OR Room 2",
      lat: 28.5985,
      lng: 77.2345,
      severity: "CRITICAL",
      reportedTime: "3 mins ago",
      timestamp: Date.now() - 3 * 60 * 1000,
      reporter: "Dr. Sarah Chen (Chief Surgeon)",
      victims: 1,
      description: "6-year-old in emergency laparotomy following blunt abdominal injury. Immediate requirement of 3 units of O-Negative PRBC.",
      requiredResources: ["O- PRBC 3 Units", "Rapid Courier / Police Green Corridor"],
      assignedUnits: [],
      unfulfilledNeeds: ["3 Units O-Negative (Regional Reserve critically low)"],
      status: "MATCHING",
      matchedHospital: "St. Jude Children Emergency Center",
      citizenProgress: 35
    }
  ],

  // First-aid flashcards for Citizens while waiting
  firstAidGuides: [
    {
      id: "cpr",
      title: "Adult CPR (Cardiac Arrest)",
      icon: "❤️‍🩹",
      steps: [
        "Check responsiveness and call for help immediately.",
        "Position hands in center of chest (interlocked fingers).",
        "Push hard and fast: 100-120 beats per minute (to rhythm of 'Stayin' Alive').",
        "Compress at least 2 inches (5 cm) deep and allow full chest recoil.",
        "Do not stop until emergency medics or AED arrives."
      ]
    },
    {
      id: "bleeding",
      title: "Severe Bleeding & Hemorrhage",
      icon: "🩸",
      steps: [
        "Apply firm, continuous direct pressure with a clean cloth or sterile gauze.",
        "Do NOT remove soaked gauze; add more layers on top.",
        "If on an extremity and life-threatening bleeding doesn't stop, apply tourniquet 2-3 inches above wound.",
        "Keep patient lying flat and warm to prevent hypovolemic shock."
      ]
    },
    {
      id: "burns",
      title: "Thermal & Chemical Burns",
      icon: "🔥",
      steps: [
        "Cool immediately with cool, running tap water for 10-20 minutes.",
        "Never apply ice, butter, or oil to a burn.",
        "Cover loosely with a clean, non-stick sterile dressing or plastic wrap.",
        "Do NOT pop blisters. Remove jewelry before swelling begins."
      ]
    },
    {
      id: "choking",
      title: "Choking (Heimlich Maneuver)",
      icon: "🫁",
      steps: [
        "Stand behind person, wrap arms around their waist.",
        "Make a fist with one hand, thumb inwards, just above the navel.",
        "Grasp fist with your other hand and deliver quick, inward and upward thrusts.",
        "Repeat until foreign object is expelled or person becomes unconscious."
      ]
    }
  ],

  // Inter-Agency Facility Crises & Shortages (Monitored Autonomously by Organization Sector)
  facilityShortages: [
    {
      id: "CRISIS-01",
      facilityId: "HOSP-01",
      facilityName: "Apex Central Trauma & Multi-Specialty Hospital",
      crisisType: "Critical Blood Shortage",
      category: "blood",
      item: "O-Negative Blood (PRBC)",
      currentStock: "1 Unit",
      thresholdMin: "8 Units",
      severity: "CRITICAL",
      detectedTime: "Just Now (IoT Telemetry)",
      details: "Mass casualty trauma incoming to Emergency Wing. RFID cold-chain sensor tripped: O-Negative reserves dropped below safety threshold (1 unit remaining, min safe: 8).",
      recommendedDonor: "Red Cross Metro Regional Blood Bank",
      donorDistance: "2.1 km",
      donorAvailableStock: "4 Units O- in reserve",
      donorContact: "+1 (800) 555-BLD1",
      suggestedAction: "LIFORA Autonomous Telemetry Engine auto-dispatched priority mutual aid request to Red Cross Metro Blood Bank",
      status: "TRANSFER_EN_ROUTE",
      autoReportSent: true,
      autoReportTargetOrg: "Red Cross Metro Regional Blood Bank",
      autoReportTelex: "[AUTONOMOUS CAD #MA-9041] URGENT SHORTAGE DETECTED AT APEX TRAUMA: O- Blood reserve depleted to 1 Unit (Min: 8). System auto-routed priority replenishment request to Red Cross Metro Regional Blood Bank. Allocation requested: 3 Units PRBC.",
      neighborOrgResponse: "[CONFIRMED - RED CROSS CAD] Autonomous report acknowledged & accepted. 3 Units O- packed in cryogenic container. Rapid-Courier dispatched under Police Green Corridor. ETA: 5 mins.",
      transferStatus: "EN_ROUTE",
      etaMinutes: 5,
      transferLog: [
        "[AUTO-ENGINE 11:20:02] Sensor detected O- Blood level < 8 Units at Apex Trauma.",
        "[AUTO-REPORT 11:20:04] Autonomous Mutual Aid Report dispatched to nearest surplus facility: Red Cross Regional Blood Bank (2.1 km).",
        "[NEIGHBOR-ACK 11:20:09] Red Cross Central CAD accepted transfer. Police Escort Unit PE-04 cleared Green Corridor."
      ]
    },
    {
      id: "CRISIS-02",
      facilityId: "HOSP-03",
      facilityName: "St. Jude Children & Maternity Emergency Center",
      crisisType: "ICU Bed Shortage",
      category: "beds",
      item: "Pediatric ICU Beds",
      currentStock: "0 Beds Free (100% Saturation)",
      thresholdMin: "3 Beds Free",
      severity: "CRITICAL",
      detectedTime: "4 mins ago",
      details: "Pediatric ICU at 100% capacity (10/10 occupied). 2 emergency admissions in triage pending immediate bed allocation.",
      recommendedDonor: "Metro General & Cardiac Care Institute",
      donorDistance: "3.2 km",
      donorAvailableStock: "5 Free ICU Beds with ventilators",
      donorContact: "+1 (800) 555-0242",
      suggestedAction: "LIFORA Autonomous Telemetry Engine transmitted automated patient diversion report to Metro General Hospital",
      status: "TRANSFER_EN_ROUTE",
      autoReportSent: true,
      autoReportTargetOrg: "Metro General & Cardiac Care Institute",
      autoReportTelex: "[AUTONOMOUS CAD #MA-9042] EMERGENCY BED SATURATION AT ST. JUDE: Pediatric ICU 0 free beds. Autonomous diversion report sent to Metro General Hospital for 2 emergency admissions.",
      neighborOrgResponse: "[CONFIRMED - METRO GENERAL CAD] Bed reservation confirmed. Beds #PICU-3 and #PICU-4 reserved with ventilators pre-calibrated. Direct ambulance diversion authorized.",
      transferStatus: "EN_ROUTE",
      etaMinutes: 8,
      transferLog: [
        "[AUTO-ENGINE 11:16:15] Bed management telemetry alerted 0% free pediatric beds at St. Jude.",
        "[AUTO-REPORT 11:16:18] Autonomous diverted assistance report sent to Metro General Hospital (3.2 km).",
        "[NEIGHBOR-ACK 11:16:22] Metro General confirmed 2 ventilator beds reserved. Inbound ambulances re-routed."
      ]
    },
    {
      id: "CRISIS-03",
      facilityId: "HOSP-04",
      facilityName: "Westside Community Emergency Clinic",
      crisisType: "Oxygen Reserve Low",
      category: "oxygen",
      item: "Liquid Medical Oxygen (Bulk)",
      currentStock: "14% Reserve",
      thresholdMin: "30% Reserve",
      severity: "HIGH",
      detectedTime: "9 mins ago",
      details: "Main oxygen manifold pressure low due to high aerosolization triage demand. Tank pressure at 14%.",
      recommendedDonor: "Apex Central Medical Logistics Depot",
      donorDistance: "4.1 km",
      donorAvailableStock: "85% Bulk Tank Surplus (24 Type-H Cylinders Ready)",
      donorContact: "+1 (800) 555-0191",
      suggestedAction: "LIFORA Autonomous Telemetry Engine auto-dispatched emergency refill telex to Apex Logistics Depot",
      status: "TRANSFER_EN_ROUTE",
      autoReportSent: true,
      autoReportTargetOrg: "Apex Central Medical Logistics Depot",
      autoReportTelex: "[AUTONOMOUS CAD #MA-9043] LOW O2 MANIFOLD TELEMETRY: Westside Community Clinic down to 14%. Autonomous refill order dispatched to Apex Logistics Depot.",
      neighborOrgResponse: "[CONFIRMED - APEX DEPOT CAD] Rapid cylinder supply truck (Unit OXY-12) loaded with 12 Type-H cryogenic cylinders. Dispatched under priority beacon.",
      transferStatus: "EN_ROUTE",
      etaMinutes: 11,
      transferLog: [
        "[AUTO-ENGINE 11:11:40] Cryogenic pressure sensor tripped 14% threshold at Westside Community Clinic.",
        "[AUTO-REPORT 11:11:42] Autonomous emergency supply request telex transmitted to Apex Depot (4.1 km).",
        "[NEIGHBOR-ACK 11:11:49] Apex Depot automated dock released Supply Truck OXY-12."
      ]
    }
  ]
};

// Export to window
window.LIFORA_DATA = LIFORA_DATA;
window.LIFEGRID_DATA = LIFORA_DATA;
