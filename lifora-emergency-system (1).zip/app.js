/**
 * LIFORA - Unified Emergency Response & Coordination Platform
 * Canva-Inspired Fluid Wave Engine, Kinetic Typography & Dual Portal Controller
 */

(function () {
  'use strict';

  // --- AUDIO SYNTHESIZER (Web Audio API) ---
  class TacticalAudioEngine {
    constructor() {
      this.ctx = null;
      this.enabled = true;
    }

    init() {
      if (!this.ctx) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (AudioContext) {
          this.ctx = new AudioContext();
        }
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
    }

    toggle() {
      this.enabled = !this.enabled;
      return this.enabled;
    }

    playTone(freq, type = 'sine', duration = 0.12, gainVal = 0.1) {
      if (!this.enabled) return;
      try {
        this.init();
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + duration);
      } catch (e) {
        console.warn('Audio play error', e);
      }
    }

    playClick() {
      this.playTone(880, 'sine', 0.05, 0.04);
    }

    playPing() {
      this.playTone(1050, 'triangle', 0.22, 0.08);
      setTimeout(() => this.playTone(1480, 'triangle', 0.25, 0.06), 90);
    }

    playKineticChord() {
      if (!this.enabled) return;
      try {
        this.init();
        if (!this.ctx) return;
        // Rising energetic kinetic chord: F - A - C - E - G
        const chord = [349.23, 440.00, 523.25, 659.25, 783.99, 1046.50];
        chord.forEach((freq, idx) => {
          setTimeout(() => {
            this.playTone(freq, 'sine', 0.35, 0.06);
          }, idx * 70);
        });
      } catch (e) {}
    }

    playWaveSound() {
      if (!this.enabled) return;
      try {
        this.init();
        if (!this.ctx) return;
        const notes = [523.25, 659.25, 783.99, 1046.50];
        notes.forEach((freq, idx) => {
          setTimeout(() => {
            this.playTone(freq, 'sine', 0.25, 0.05);
          }, idx * 60);
        });
      } catch (e) {}
    }

    playDispatch() {
      this.playTone(440, 'sine', 0.18, 0.1);
      setTimeout(() => this.playTone(554.37, 'sine', 0.18, 0.1), 100);
      setTimeout(() => this.playTone(659.25, 'sine', 0.3, 0.12), 200);
    }

    playAlert() {
      this.playTone(920, 'sawtooth', 0.16, 0.1);
      setTimeout(() => this.playTone(680, 'sawtooth', 0.2, 0.1), 150);
    }
  }

  // --- STATE ---
  const DATA = window.LIFORA_DATA || window.LIFEGRID_DATA;
  const state = {
    currentSector: 'portal-selection-gateway', // Starts at Kinetic Gateway with the 2 Portal choices
    map: null,
    mapMarkers: {},
    audio: new TacticalAudioEngine(),
    simulationActive: false,
    simulationTimer: null,
    activeIncidentForTracker: null,
    resourceFilterCat: 'all',
    resourceSearchQuery: '',
    mapLayerFilters: {
      hospitals: true,
      ambulances: true,
      fire: true,
      blood: true,
      incidents: true
    },
    taskLogs: [
      { time: '10:24:12', tag: 'DISPATCH', text: 'Medic-Bravo 4 assigned to Incident #INC-8941 (ETA 3 mins)' },
      { time: '10:22:45', tag: 'POLICE', text: 'Metro North Squad Car 12 arrived on scene at Central Interchange' },
      { time: '10:19:10', tag: 'LIFORA-SYS', text: 'Incident #INC-8941 registered via Citizen Emergency App' },
      { time: '10:14:00', tag: 'AUDIT', text: 'Apex Central Trauma bed telemetry synchronized (14 ICU available)' },
      { time: '10:05:30', tag: 'FIRE', text: 'Central Fire Engine 1 declared containment on Civic Plaza false ceiling' }
    ]
  };

  // --- INITIALIZATION ---
  function init() {
    state.activeIncidentForTracker = DATA.incidents[0];

    setupSectorSwitcher();
    setupAudioToggle();
    setupCitizenSector();
    setupOrganizationSector();
    setupModals();
    renderAll();

    // Trigger initial kinetic entrance animation
    replayKineticTypography();

    // Initialize map
    setTimeout(() => {
      initTacticalMap();
    }, 250);

    showToast('Welcome to LIFORA. Select Citizen Portal or Organization Portal.', 'success');
  }

  // --- STYLISH WAVE TRANSITIONS & RIPPLES ---
  function triggerWaveTransition(callback) {
    state.audio.playWaveSound();

    // Immediately reset scroll to 0 so there is no delay
    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;

    const overlay = document.getElementById('wave-overlay');
    if (!overlay) {
      if (callback) callback();
      window.scrollTo(0, 0);
      return;
    }

    overlay.classList.remove('exit');
    overlay.classList.add('active');

    setTimeout(() => {
      if (callback) callback();
      window.scrollTo(0, 0);
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;

      setTimeout(() => {
        overlay.classList.add('exit');
        setTimeout(() => {
          overlay.classList.remove('active', 'exit');
          window.scrollTo(0, 0);
        }, 550);
      }, 100);
    }, 280);
  }

  function createWaveRipple(e) {
    if (!e || !e.clientX) return;
    const ripple = document.createElement('div');
    ripple.className = 'wave-click-ripple';
    ripple.style.left = `${e.clientX}px`;
    ripple.style.top = `${e.clientY}px`;
    document.body.appendChild(ripple);

    setTimeout(() => ripple.remove(), 750);
  }

  // --- KINETIC TYPOGRAPHY ENTRANCE TRIGGER ---
  function triggerKineticEntrance(e) {
    if (e) createWaveRipple(e);
    state.audio.playKineticChord();

    triggerWaveTransition(() => {
      openPortalGateway();
      replayKineticTypography();
    });
  }

  function replayKineticTypography() {
    const letters = document.querySelectorAll('.kinetic-letter');
    letters.forEach(letter => {
      letter.style.animation = 'none';
      letter.offsetHeight; // Trigger reflow
      letter.style.animation = '';
    });
  }

  function openPortalGateway(event) {
    if (event) createWaveRipple(event);
    state.currentSector = 'portal-selection-gateway';

    // Deselect active tabs in top nav
    const tabCitizens = document.getElementById('tab-btn-citizens');
    const tabOrgs = document.getElementById('tab-btn-orgs');
    if (tabCitizens) tabCitizens.classList.remove('active');
    if (tabOrgs) tabOrgs.classList.remove('active');

    document.querySelectorAll('.sector-section').forEach(sec => {
      if (sec.id === 'portal-selection-gateway') {
        sec.classList.add('active-sector');
      } else {
        sec.classList.remove('active-sector');
      }
    });

    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;

    replayKineticTypography();
  }

  // --- SECTOR SWITCHER (Citizens vs Organizations ONLY) ---
  function setupSectorSwitcher() {
    const tabCitizens = document.getElementById('tab-btn-citizens');
    const tabOrgs = document.getElementById('tab-btn-orgs');

    if (tabCitizens) {
      tabCitizens.addEventListener('click', (e) => {
        createWaveRipple(e);
        switchSectorWithWave('citizen-sector');
      });
    }

    if (tabOrgs) {
      tabOrgs.addEventListener('click', (e) => {
        createWaveRipple(e);
        switchSectorWithWave('organization-sector');
      });
    }
  }

  function switchSectorWithWave(sectorId, event) {
    if (event) createWaveRipple(event);
    if (state.currentSector === sectorId) {
      window.scrollTo(0, 0);
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
      return;
    }

    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;

    triggerWaveTransition(() => {
      applySectorChange(sectorId);
    });
  }

  function applySectorChange(sectorId) {
    state.currentSector = sectorId;

    const switcherBox = document.getElementById('sector-switcher-box');
    const tabCitizens = document.getElementById('tab-btn-citizens');
    const tabOrgs = document.getElementById('tab-btn-orgs');

    if (sectorId === 'organization-sector') {
      switcherBox.classList.add('org-active');
      tabOrgs.classList.add('active');
      tabCitizens.classList.remove('active');
    } else if (sectorId === 'citizen-sector') {
      switcherBox.classList.remove('org-active');
      tabCitizens.classList.add('active');
      tabOrgs.classList.remove('active');
    }

    // Toggle Sector Views
    document.querySelectorAll('.sector-section').forEach(sec => {
      if (sec.id === sectorId) {
        sec.classList.add('active-sector');
      } else {
        sec.classList.remove('active-sector');
      }
    });

    // Ensure the page and active sector are at the very top
    const targetSec = document.getElementById(sectorId);
    if (targetSec) {
      targetSec.scrollIntoView({ behavior: 'instant', block: 'start' });
    }
    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;

    // Invalidate map if entering organization sector
    if (sectorId === 'organization-sector') {
      setTimeout(() => {
        if (state.map) {
          state.map.invalidateSize();
        } else {
          initTacticalMap();
        }
      }, 150);
    }
  }

  // --- AUDIO SETUP ---
  function setupAudioToggle() {
    const btn = document.getElementById('audio-toggle-btn');
    if (!btn) return;
    btn.addEventListener('click', (e) => {
      createWaveRipple(e);
      const isEnabled = state.audio.toggle();
      if (isEnabled) {
        btn.classList.add('active');
        state.audio.playPing();
        showToast('Tactical audio feedback enabled', 'success');
      } else {
        btn.classList.remove('active');
        showToast('Audio muted', 'normal');
      }
    });
  }

  // --- TACTICAL LEAFLET MAP ---
  function initTacticalMap() {
    const mapElement = document.getElementById('tactical-leaflet-map');
    if (!mapElement || state.map) return;

    try {
      state.map = L.map('tactical-leaflet-map', {
        center: DATA.mapCenter,
        zoom: DATA.defaultZoom,
        zoomControl: false,
        attributionControl: false
      });

      L.control.zoom({ position: 'topright' }).addTo(state.map);

      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        subdomains: 'abcd'
      }).addTo(state.map);

      renderMapMarkers();

      document.querySelectorAll('.layer-filter-chip').forEach(chip => {
        chip.addEventListener('click', (e) => {
          createWaveRipple(e);
          state.audio.playClick();
          const layer = chip.getAttribute('data-layer');
          chip.classList.toggle('active');
          state.mapLayerFilters[layer] = chip.classList.contains('active');
          renderMapMarkers();
        });
      });

    } catch (err) {
      console.error('Tactical map initialization failed:', err);
    }
  }

  function renderMapMarkers() {
    if (!state.map) return;

    for (let key in state.mapMarkers) {
      state.map.removeLayer(state.mapMarkers[key]);
    }
    state.mapMarkers = {};

    // 1. Hospitals
    if (state.mapLayerFilters.hospitals) {
      DATA.hospitals.forEach(h => {
        const icon = L.divIcon({
          className: 'tactical-div-icon',
          html: `<div class="tactical-marker-pin hospital" title="${h.name}">🏥</div>`,
          iconSize: [36, 36],
          iconAnchor: [18, 18]
        });

        const marker = L.marker([h.lat, h.lng], { icon }).addTo(state.map);
        marker.bindPopup(`
          <div style="font-size: 0.85rem;">
            <div style="font-weight: 700; color: #60a5fa; margin-bottom: 4px;">🏥 ${h.name}</div>
            <div style="color: #94a3b8; font-size: 0.74rem; margin-bottom: 6px;">${h.type}</div>
            <div style="background: rgba(255,255,255,0.06); padding: 6px; border-radius: 6px; margin-bottom: 8px;">
              <div><strong>ICU Beds:</strong> <span style="color: #34d399; font-weight: 700;">${h.icuBeds}</span> / ${h.totalIcuBeds}</div>
              <div><strong>General:</strong> ${h.generalBeds} / ${h.totalGeneralBeds}</div>
              <div><strong>Freshness:</strong> <span style="color: ${h.lastVerifiedMinutesAgo > 30 ? '#f59e0b' : '#34d399'};">${h.lastVerifiedMinutesAgo}m ago</span></div>
            </div>
            <button onclick="window.LIFORA_APP.verifyResource('${h.id}')" style="background: #2563eb; color: #fff; border: none; padding: 4px 10px; border-radius: 4px; font-size: 0.75rem; cursor: pointer; width: 100%;">Ping &amp; Verify Telemetry</button>
          </div>
        `);
        state.mapMarkers[`hosp_${h.id}`] = marker;
      });
    }

    // 2. Ambulances
    if (state.mapLayerFilters.ambulances) {
      DATA.ambulances.forEach(a => {
        const icon = L.divIcon({
          className: 'tactical-div-icon',
          html: `<div class="tactical-marker-pin ambulance" title="${a.callSign}">🚑</div>`,
          iconSize: [36, 36],
          iconAnchor: [18, 18]
        });

        const marker = L.marker([a.lat, a.lng], { icon }).addTo(state.map);
        marker.bindPopup(`
          <div style="font-size: 0.85rem;">
            <div style="font-weight: 700; color: #34d399; margin-bottom: 4px;">🚑 ${a.callSign}</div>
            <div style="font-size: 0.75rem; color: #cbd5e1; margin-bottom: 6px;">Type: <strong>${a.type}</strong></div>
            <div style="background: rgba(255,255,255,0.06); padding: 6px; border-radius: 6px; margin-bottom: 8px;">
              <div><strong>Status:</strong> <span style="color: ${a.status === 'Available' ? '#34d399' : '#f59e0b'}; font-weight: 700;">${a.status}</span></div>
              <div><strong>Crew:</strong> ${a.crew}</div>
              <div><strong>Fuel/Battery:</strong> ${a.fuelPct}%</div>
            </div>
            <button onclick="window.LIFORA_APP.focusOnResource('${a.id}')" style="background: #059669; color: #fff; border: none; padding: 4px 10px; border-radius: 4px; font-size: 0.75rem; cursor: pointer; width: 100%;">Direct Fleet Comms</button>
          </div>
        `);
        state.mapMarkers[`amb_${a.id}`] = marker;
      });
    }

    // 3. Fire Stations
    if (state.mapLayerFilters.fire) {
      DATA.fireStations.forEach(f => {
        const icon = L.divIcon({
          className: 'tactical-div-icon',
          html: `<div class="tactical-marker-pin fire" title="${f.name}">🚒</div>`,
          iconSize: [36, 36],
          iconAnchor: [18, 18]
        });

        const marker = L.marker([f.lat, f.lng], { icon }).addTo(state.map);
        marker.bindPopup(`
          <div style="font-size: 0.85rem;">
            <div style="font-weight: 700; color: #fb923c; margin-bottom: 4px;">🚒 ${f.name}</div>
            <div style="font-size: 0.75rem; color: #cbd5e1;">Available Engines: <strong>${f.enginesAvailable}</strong> / ${f.totalEngines}</div>
            <div style="font-size: 0.75rem; color: #cbd5e1;">Hazmat Ready: <strong>${f.hazmatTeamReady ? 'YES' : 'NO'}</strong></div>
          </div>
        `);
        state.mapMarkers[`fire_${f.id}`] = marker;
      });
    }

    // 4. Blood Banks
    if (state.mapLayerFilters.blood) {
      DATA.bloodBanks.forEach(b => {
        const icon = L.divIcon({
          className: 'tactical-div-icon',
          html: `<div class="tactical-marker-pin blood" title="${b.name}">🩸</div>`,
          iconSize: [36, 36],
          iconAnchor: [18, 18]
        });

        const marker = L.marker([b.lat, b.lng], { icon }).addTo(state.map);
        marker.bindPopup(`
          <div style="font-size: 0.85rem;">
            <div style="font-weight: 700; color: #f472b6; margin-bottom: 4px;">🩸 ${b.name}</div>
            <div style="background: rgba(255,255,255,0.06); padding: 6px; border-radius: 6px; margin-bottom: 6px;">
              <div><strong>O- Reserve:</strong> <span style="color: ${b.inventory['O-'] < 5 ? '#ff3366' : '#34d399'}; font-weight: 700;">${b.inventory['O-']} units</span></div>
              <div><strong>O+ Reserve:</strong> ${b.inventory['O+']} units</div>
            </div>
          </div>
        `);
        state.mapMarkers[`bld_${b.id}`] = marker;
      });
    }

    // 5. Active Incidents
    if (state.mapLayerFilters.incidents) {
      DATA.incidents.forEach(inc => {
        const icon = L.divIcon({
          className: 'tactical-div-icon',
          html: `<div class="tactical-marker-pin incident" title="${inc.title}">🚨</div>`,
          iconSize: [40, 40],
          iconAnchor: [20, 20]
        });

        const marker = L.marker([inc.lat, inc.lng], { icon }).addTo(state.map);
        marker.bindPopup(`
          <div style="font-size: 0.85rem; max-width: 250px;">
            <div style="font-weight: 800; color: #ff6b8b; margin-bottom: 4px;">🚨 ${inc.title}</div>
            <div style="font-size: 0.72rem; color: #fca5a5; font-weight: 700; margin-bottom: 6px;">${inc.severity} • ${inc.status}</div>
            <p style="font-size: 0.78rem; color: #cbd5e1; margin-bottom: 8px;">${inc.description}</p>
            <button onclick="window.LIFORA_APP.selectIncidentForTracker('${inc.id}')" style="background: #e11d48; color: #fff; border: none; padding: 5px 10px; border-radius: 4px; font-size: 0.75rem; cursor: pointer; width: 100%;">Track in Citizen Portal</button>
          </div>
        `);
        state.mapMarkers[`inc_${inc.id}`] = marker;
      });
    }
  }

  // --- QUICK SOS ACTIONS ---
  function quickSOS(category, event) {
    createWaveRipple(event);
    state.audio.playAlert();
    openReportModal(category);
  }

  // --- CITIZEN SECTOR SETUP & RENDER ---
  function setupCitizenSector() {
    const catTabs = document.querySelectorAll('#resource-cat-tabs .cat-pill-btn');
    catTabs.forEach(tab => {
      tab.addEventListener('click', (e) => {
        createWaveRipple(e);
        state.audio.playClick();
        catTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        state.resourceFilterCat = tab.getAttribute('data-cat');
        renderResourceDirectory();
      });
    });

    const searchInput = document.getElementById('resource-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        state.resourceSearchQuery = e.target.value.toLowerCase().trim();
        renderResourceDirectory();
      });
    }

    // Inline report severity selector
    const sevOptions = document.querySelectorAll('#inline-rep-severity-selector .sev-option');
    sevOptions.forEach(opt => {
      opt.addEventListener('click', (e) => {
        createWaveRipple(e);
        state.audio.playClick();
        sevOptions.forEach(o => o.classList.remove('selected'));
        opt.classList.add('selected');
        const hiddenSev = document.getElementById('inline-rep-severity');
        if (hiddenSev) hiddenSev.value = opt.getAttribute('data-sev');
      });
    });

    renderCitizenTracker();
    renderConnectedAgencies();
    renderResourceDirectory();
  }

  function renderCitizenTracker() {
    const inc = state.activeIncidentForTracker || DATA.incidents[0];
    if (!inc) return;

    document.getElementById('tracker-incident-title').innerText = `Incident #${inc.id}: ${inc.title}`;
    document.getElementById('tracker-tracking-id').innerText = `TICKET: LF-${inc.id.replace('INC-', '')}-${inc.category ? inc.category.toUpperCase().slice(0, 3) : 'MED'}`;

    let progressPct = inc.citizenProgress || 60;
    const line = document.getElementById('stepper-progress-line');
    if (line) line.style.width = `${progressPct}%`;

    const stepNodes = [
      document.getElementById('step-node-1'),
      document.getElementById('step-node-2'),
      document.getElementById('step-node-3'),
      document.getElementById('step-node-4'),
      document.getElementById('step-node-5')
    ];

    stepNodes.forEach((node, idx) => {
      if (!node) return;
      const stepPct = (idx + 1) * 20;
      node.classList.remove('active', 'completed');
      if (progressPct >= stepPct) {
        node.classList.add('completed');
      } else if (progressPct >= stepPct - 15) {
        node.classList.add('active');
      }
    });

    if (inc.assignedUnits && inc.assignedUnits.length > 0) {
      const u = inc.assignedUnits[0];
      document.getElementById('tracker-unit-name').innerText = `🚑 ${u.name} (${u.type})`;
      document.getElementById('tracker-eta-badge').innerText = `⏱️ ${u.status.includes('ETA') ? u.status : 'ETA: 3 MINS'}`;
    } else {
      document.getElementById('tracker-unit-name').innerText = `Smart Matching Responders...`;
      document.getElementById('tracker-eta-badge').innerText = `⏱️ DISPATCHING`;
    }

    if (inc.matchedHospital) {
      document.getElementById('tracker-destination-hosp').innerText = inc.matchedHospital;
    }
  }

  function renderConnectedAgencies() {
    const container = document.getElementById('agency-response-cards-grid');
    if (!container) return;

    const inc = state.activeIncidentForTracker || DATA.incidents[0];
    if (!inc) {
      container.innerHTML = `<div style="grid-column: 1/-1; text-align: center; color: var(--text-muted); padding: 1.5rem;">No active emergency incident being tracked.</div>`;
      return;
    }

    if (!inc.connectedAgencies || inc.connectedAgencies.length === 0) {
      inc.connectedAgencies = generateConnectedAgenciesForIncident(inc);
    }

    const pill = document.getElementById('agency-active-pill');
    if (pill) {
      const activeCount = inc.connectedAgencies.length;
      pill.innerText = `${activeCount} ORGANIZATIONS NOTIFIED & ACTING`;
    }

    let html = '';
    inc.connectedAgencies.forEach(ag => {
      let statusClass = 'dispatched';
      let statusIcon = '⚡';
      if (ag.status === 'ACKNOWLEDGED') {
        statusClass = 'acknowledged';
        statusIcon = '✓';
      } else if (ag.status === 'EN_ROUTE') {
        statusClass = 'en-route';
        statusIcon = '🚑';
      } else if (ag.status === 'ON_SCENE') {
        statusClass = 'on-scene';
        statusIcon = '🚨';
      }

      html += `
        <div class="agency-response-card ${statusClass}">
          <div class="agency-card-top">
            <div class="agency-type-badge">
              <span class="agency-icon">${ag.icon || '🏢'}</span>
              <span>${ag.type}</span>
            </div>
            <span class="agency-status-pill ${statusClass}">
              <span class="pulse-indicator"></span>
              <span>${statusIcon} ${ag.status.replace('_', ' ')}</span>
            </span>
          </div>

          <h5 class="agency-org-name">${ag.name}</h5>
          <div class="agency-role-desc">Mission: <strong>${ag.role}</strong></div>

          <div class="agency-action-callout">
            <div class="action-label">DIRECTIVE / ACTION TAKEN</div>
            <div class="action-text">"${ag.actionTaken}"</div>
          </div>

          <div class="agency-footer-row">
            <div class="agency-eta-info">
              <span class="eta-icon">⏱️</span>
              <span class="eta-val">${ag.eta}</span>
            </div>
            <div style="display: flex; gap: 0.5rem;">
              <a href="tel:${ag.phone || '112'}" class="btn-agency-call" onclick="window.LIFORA_APP.createWaveRipple(event)" title="Direct Telemetry Line">
                <span>📞 Call</span>
              </a>
              <button type="button" class="btn-agency-view" onclick="window.LIFORA_APP.acknowledgeAgency('${ag.id}', '${inc.id}', event)" title="Acknowledge Status">
                <span>✓ Status</span>
              </button>
            </div>
          </div>
        </div>
      `;
    });

    container.innerHTML = html;
  }

  function generateConnectedAgenciesForIncident(inc) {
    const isFire = inc.category === 'fire';
    const isBlood = inc.category === 'blood';

    return [
      {
        id: 'AGY-HOSP',
        type: 'Trauma Hospital',
        name: inc.matchedHospital || 'Apex Central Trauma & Multi-Specialty Hospital',
        role: 'ER Triage & Trauma Resuscitation Standby',
        status: 'ACKNOWLEDGED',
        actionTaken: 'Emergency trauma team pre-alerted with surgical bay and blood reserve prepared.',
        eta: 'Ready on Arrival',
        icon: '🏥',
        phone: '+1 (800) 555-0191'
      },
      {
        id: 'AGY-EMS',
        type: 'Paramedic EMS',
        name: 'Medic-Bravo 4 (ACLS Unit)',
        role: 'Advanced Life Support & Rapid Medical Transit',
        status: 'EN_ROUTE',
        actionTaken: 'En route with full life-support kit and telemetry uplink.',
        eta: '3 mins (1.2 km)',
        icon: '🚑',
        phone: '+1 (800) 555-AMB4'
      },
      {
        id: 'AGY-POL',
        type: 'Highway Police',
        name: 'Metro North Squad Car 12',
        role: 'Intersection Green Corridor & Perimeter Control',
        status: 'ON_SCENE',
        actionTaken: 'Traffic cleared along highway approach to ensure unimpeded rescue transit.',
        eta: 'On Scene',
        icon: '🚓',
        phone: '+1 (800) 555-100'
      },
      {
        id: 'AGY-FIRE',
        type: 'Fire Rescue Squad',
        name: 'Central Fire Rescue Unit 1',
        role: isFire ? 'Primary Fire Suppression & Containment' : 'Hydraulic Extrication & Hazard Securing',
        status: 'DISPATCHED',
        actionTaken: isFire ? 'Pumper truck and aerial ladder deployed to scene.' : 'Heavy rescue cutters and scene illumination active.',
        eta: '4 mins (1.8 km)',
        icon: '🚒',
        phone: '+1 (800) 555-FIRE1'
      }
    ];
  }

  function acknowledgeAgency(agencyId, incidentId, event) {
    if (event) createWaveRipple(event);
    state.audio.playClick();

    const inc = DATA.incidents.find(i => i.id === incidentId) || state.activeIncidentForTracker;
    if (inc && inc.connectedAgencies) {
      const ag = inc.connectedAgencies.find(a => a.id === agencyId);
      if (ag) {
        if (ag.status === 'ACKNOWLEDGED') {
          ag.status = 'EN_ROUTE';
          ag.actionTaken = 'Unit underway with siren and emergency optical beacons.';
        } else if (ag.status === 'EN_ROUTE') {
          ag.status = 'ON_SCENE';
          ag.actionTaken = 'Unit has arrived on scene and begun incident management operations.';
          ag.eta = 'On Scene';
        } else if (ag.status === 'DISPATCHED') {
          ag.status = 'ACKNOWLEDGED';
        }
        renderConnectedAgencies();
        showToast(`Updated status for ${ag.name}: ${ag.status.replace('_', ' ')}`, 'normal');
      }
    }
  }

  function renderResourceDirectory() {
    const container = document.getElementById('resources-cards-container');
    if (!container) return;

    let items = [];
    const cat = state.resourceFilterCat;

    if (cat === 'all' || cat === 'hospitals') {
      DATA.hospitals.forEach(h => items.push({ type: 'Hospital', raw: h }));
    }
    if (cat === 'all' || cat === 'ambulances') {
      DATA.ambulances.forEach(a => items.push({ type: 'Ambulance', raw: a }));
    }
    if (cat === 'all' || cat === 'blood') {
      DATA.bloodBanks.forEach(b => items.push({ type: 'Blood Bank', raw: b }));
    }
    if (cat === 'all' || cat === 'fire') {
      DATA.fireStations.forEach(f => items.push({ type: 'Fire Station', raw: f }));
    }
    if (cat === 'all' || cat === 'police') {
      DATA.policeUnits.forEach(p => items.push({ type: 'Police Unit', raw: p }));
    }

    if (state.resourceSearchQuery) {
      const q = state.resourceSearchQuery;
      items = items.filter(item => {
        const name = (item.raw.name || item.raw.callSign || '').toLowerCase();
        const address = (item.raw.address || item.raw.baseStation || '').toLowerCase();
        const type = (item.raw.type || '').toLowerCase();
        return name.includes(q) || address.includes(q) || type.includes(q);
      });
    }

    if (items.length === 0) {
      container.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; padding: 3rem 1rem; color: var(--text-secondary);">
          <div style="font-size: 2.2rem; margin-bottom: 0.5rem;">🔍</div>
          <h4>No emergency resources found matching "${state.resourceSearchQuery}"</h4>
          <p style="font-size: 0.85rem;">Try adjusting your filter or search terms.</p>
        </div>
      `;
      return;
    }

    let html = '';
    items.forEach(item => {
      const d = item.raw;
      const type = item.type;

      const freshnessMins = d.lastVerifiedMinutesAgo !== undefined ? d.lastVerifiedMinutesAgo : 5;
      let badgeClass = 'high';
      let badgeLabel = `✓ Verified ${freshnessMins}m ago`;
      if (freshnessMins > 45) {
        badgeClass = 'stale';
        badgeLabel = `⚠️ Stale Data (${freshnessMins}m)`;
      } else if (freshnessMins > 20) {
        badgeClass = 'medium';
        badgeLabel = `⏱️ ${freshnessMins}m ago`;
      }

      let metricsHtml = '';
      if (type === 'Hospital') {
        metricsHtml = `
          <div class="resource-metrics-strip">
            <div class="metric-cell">
              <div class="val green">${d.icuBeds}</div>
              <div class="lbl">ICU Beds</div>
            </div>
            <div class="metric-cell">
              <div class="val">${d.generalBeds}</div>
              <div class="lbl">General</div>
            </div>
            <div class="metric-cell">
              <div class="val ${d.oxygenAvailable ? 'green' : 'crimson'}">${d.oxygenAvailable ? 'YES' : 'NO'}</div>
              <div class="lbl">Oxygen</div>
            </div>
          </div>
        `;
      } else if (type === 'Ambulance') {
        metricsHtml = `
          <div class="resource-metrics-strip">
            <div class="metric-cell">
              <div class="val green">${d.status}</div>
              <div class="lbl">Status</div>
            </div>
            <div class="metric-cell">
              <div class="val">${d.etaMinutes}m</div>
              <div class="lbl">ETA</div>
            </div>
            <div class="metric-cell">
              <div class="val">${d.fuelPct}%</div>
              <div class="lbl">Battery/Fuel</div>
            </div>
          </div>
        `;
      } else if (type === 'Blood Bank') {
        metricsHtml = `
          <div class="resource-metrics-strip">
            <div class="metric-cell">
              <div class="val ${d.inventory['O-'] < 5 ? 'crimson' : 'green'}">${d.inventory['O-']} u</div>
              <div class="lbl">O- Critical</div>
            </div>
            <div class="metric-cell">
              <div class="val">${d.inventory['O+']} u</div>
              <div class="lbl">O+ Stock</div>
            </div>
            <div class="metric-cell">
              <div class="val">${d.inventory['Platelets']} u</div>
              <div class="lbl">Platelets</div>
            </div>
          </div>
        `;
      } else if (type === 'Fire Station') {
        metricsHtml = `
          <div class="resource-metrics-strip">
            <div class="metric-cell">
              <div class="val green">${d.enginesAvailable}</div>
              <div class="lbl">Engines</div>
            </div>
            <div class="metric-cell">
              <div class="val">${d.ladderTrucks}</div>
              <div class="lbl">Ladders</div>
            </div>
            <div class="metric-cell">
              <div class="val ${d.hazmatTeamReady ? 'green' : 'amber'}">${d.hazmatTeamReady ? 'READY' : 'STANDBY'}</div>
              <div class="lbl">Hazmat</div>
            </div>
          </div>
        `;
      } else {
        metricsHtml = `
          <div class="resource-metrics-strip">
            <div class="metric-cell">
              <div class="val green">${d.status}</div>
              <div class="lbl">Status</div>
            </div>
            <div class="metric-cell">
              <div class="val">${d.etaMinutes}m</div>
              <div class="lbl">Intercept</div>
            </div>
            <div class="metric-cell">
              <div class="val">${d.officers}</div>
              <div class="lbl">Officers</div>
            </div>
          </div>
        `;
      }

      html += `
        <div class="canva-resource-card">
          <div class="card-top-tags">
            <span class="type-pill">${type}</span>
            <span class="freshness-badge ${badgeClass}">${badgeLabel}</span>
          </div>

          <h4>${d.name || d.callSign}</h4>
          <div class="card-address">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
            <span>${d.address || d.baseStation || 'Metropolitan Sector'}</span>
          </div>

          ${metricsHtml}

          <div class="card-actions-row">
            <button class="btn-card-primary" onclick="window.LIFORA_APP.focusOnMap(${d.lat}, ${d.lng}, '${d.name || d.callSign}')">
              <span>📍 View on Tactical Map</span>
            </button>
            <a href="tel:${d.phone || d.contact || '112'}" class="btn-card-call" onclick="window.LIFORA_APP.createWaveRipple(event)">
              <span>📞 Direct Call</span>
            </a>
          </div>
        </div>
      `;
    });

    container.innerHTML = html;
  }

  function renderFirstAidGuides() {
    const container = document.getElementById('first-aid-container');
    if (!container) return;

    let html = '';
    DATA.firstAidGuides.forEach(guide => {
      html += `
        <div class="fa-card-item">
          <div class="fa-card-header">
            <span class="icon">${guide.icon}</span>
            <h5>${guide.title}</h5>
          </div>
          <ol>
            ${guide.steps.map(s => `<li>${s}</li>`).join('')}
          </ol>
        </div>
      `;
    });
    container.innerHTML = html;
  }

  // --- ORGANIZATION SECTOR SETUP & COMMAND MODULES ---
  function setupOrganizationSector() {
    const cmdTabs = document.querySelectorAll('.cmd-tab-link');
    cmdTabs.forEach(tab => {
      tab.addEventListener('click', (e) => {
        createWaveRipple(e);
        state.audio.playClick();
        cmdTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        const targetId = tab.getAttribute('data-target');
        document.querySelectorAll('.cmd-pane').forEach(p => p.classList.remove('active-pane'));
        const pane = document.getElementById(targetId);
        if (pane) pane.classList.add('active-pane');
      });
    });

    const simBtn = document.getElementById('simulation-toggle-btn');
    if (simBtn) {
      simBtn.addEventListener('click', (e) => {
        createWaveRipple(e);
        toggleSimulation();
      });
    }

    renderFacilityShortages();
    renderSmartMatchingIncidents();
    renderReliabilityAuditor();
    renderTaskLogs();
  }

  function renderFacilityShortages() {
    const container = document.getElementById('facility-shortages-container');
    if (!container) return;

    if (!DATA.facilityShortages || DATA.facilityShortages.length === 0) {
      container.innerHTML = `<div style="text-align: center; color: var(--text-muted); padding: 2rem;">No facility shortages detected across the grid.</div>`;
      return;
    }

    let html = '';
    const totalAlertCount = DATA.facilityShortages.length;

    DATA.facilityShortages.forEach(s => {
      const isCritical = s.severity === 'CRITICAL';

      const severityBadge = isCritical 
        ? `<span class="sector-pill-tag" style="background: rgba(244, 63, 94, 0.2); color: #f43f5e; border: 1px solid rgba(244, 63, 94, 0.4); font-weight: 800;">🚨 ${s.severity} DEFICIT</span>`
        : `<span class="sector-pill-tag" style="background: rgba(245, 158, 11, 0.2); color: #f59e0b; border: 1px solid rgba(245, 158, 11, 0.4); font-weight: 800;">⚠️ ${s.severity} DEFICIT</span>`;

      const autoStatusPill = `
        <span class="autonomous-badge-glow">
          <span class="live-pulse-dot" style="width: 7px; height: 7px;"></span>
          <span>🤖 AUTO-REPORT SENT &amp; AID IN TRANSIT</span>
        </span>
      `;

      html += `
        <div class="crisis-shortage-card ${isCritical ? 'critical' : 'high'}" id="card-${s.id}">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 1rem; margin-bottom: 0.85rem; flex-wrap: wrap;">
            <div>
              <div style="font-size: 0.74rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 0.25rem;">
                IoT SENSOR DETECTION • ${s.detectedTime}
              </div>
              <h4 style="font-size: 1.22rem; font-weight: 800; color: #fff; margin-bottom: 0.35rem; display: flex; align-items: center; gap: 0.5rem;">
                <span>🏥</span>
                <span>${s.facilityName}</span>
              </h4>
              <div style="display: flex; gap: 0.75rem; align-items: center; flex-wrap: wrap;">
                <span style="color: #fca5a5; font-weight: 700; font-size: 0.95rem;">🚨 ${s.crisisType}: <strong>${s.item}</strong></span>
                <span class="mono" style="background: rgba(255,255,255,0.06); padding: 3px 9px; border-radius: 4px; font-size: 0.8rem;">
                  Current: <strong style="color: #f43f5e;">${s.currentStock}</strong> (Safety Min: ${s.thresholdMin})
                </span>
              </div>
            </div>
            <div style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">
              ${severityBadge}
              ${autoStatusPill}
            </div>
          </div>

          <p style="font-size: 0.85rem; color: #cbd5e1; line-height: 1.5; margin-bottom: 1rem; background: rgba(0,0,0,0.28); padding: 0.85rem; border-radius: var(--radius-sm); border-left: 3px solid rgba(255,255,255,0.15);">
            ${s.details}
          </p>

          <!-- Autonomous Solution: Nearest Organization Matched -->
          <div class="smart-donor-box">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.65rem; flex-wrap: wrap; gap: 0.5rem;">
              <span style="font-weight: 800; color: var(--canva-cyan); font-size: 0.86rem; display: flex; align-items: center; gap: 0.45rem;">
                <span>✨ Nearest Responding Neighbor Identified</span>
              </span>
              <span class="sector-pill-tag" style="background: rgba(6, 182, 212, 0.2); color: var(--canva-cyan); font-size: 0.74rem; font-weight: 800;">
                PROXIMITY: ${s.donorDistance}
              </span>
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 0.85rem; margin-bottom: 0.65rem; font-size: 0.82rem;">
              <div>
                <span style="color: var(--text-muted); font-size: 0.72rem; display: block; font-weight: 600;">NEIGHBORING DONOR FACILITY</span>
                <strong style="color: #fff; font-size: 0.9rem;">${s.recommendedDonor}</strong>
              </div>
              <div>
                <span style="color: var(--text-muted); font-size: 0.72rem; display: block; font-weight: 600;">AVAILABLE SURPLUS STOCK</span>
                <strong style="color: #34d399; font-size: 0.9rem;">${s.donorAvailableStock}</strong>
              </div>
              <div>
                <span style="color: var(--text-muted); font-size: 0.72rem; display: block; font-weight: 600;">DIRECT CONTACT</span>
                <strong style="color: #e2e8f0; font-family: var(--font-mono);">${s.donorContact}</strong>
              </div>
            </div>
          </div>

          <!-- Autonomous Report & CAD Telemetry Box (Zero Manual Input Required) -->
          <div class="auto-report-box">
            <div class="auto-report-header">
              <span style="font-weight: 800; color: #fff; font-size: 0.86rem; display: flex; align-items: center; gap: 0.45rem;">
                <span>📡</span>
                <span>Autonomous Mutual Aid Dispatch (Zero Manual Input Required)</span>
              </span>
              <span class="sector-pill-tag" style="background: rgba(16, 185, 129, 0.2); color: #34d399; font-size: 0.72rem; font-weight: 800;">
                ✓ REPORT AUTO-DISPATCHED &amp; CONFIRMED
              </span>
            </div>

            <div class="auto-cad-message">
              <strong style="color: #38bdf8;">📤 AUTOMATED CAD REPORT SENT ➔ ${s.autoReportTargetOrg || s.recommendedDonor}:</strong><br>
              ${s.autoReportTelex || 'Emergency shortage detected. Assistance report auto-transmitted to neighbor.'}
            </div>

            <div class="neighbor-response-box">
              <strong style="color: #4ade80;">📥 AUTOMATED CONFIRMATION RECEIVED ⬅ ${s.autoReportTargetOrg || s.recommendedDonor}:</strong><br>
              ${s.neighborOrgResponse || 'Mutual aid request accepted. Relief dispatched under Police Green Corridor.'}
            </div>

            <!-- 5-Step Live Progress Stepper -->
            <div class="auto-stepper-strip">
              <span class="auto-step-pill completed">✓ 1. Shortage Tripped</span>
              <span class="auto-step-pill completed">✓ 2. Auto-Report Sent</span>
              <span class="auto-step-pill completed">✓ 3. Neighbor Accepted</span>
              <span class="auto-step-pill active">🟢 4. Green Corridor Escort (ETA: ${s.etaMinutes || 5} min)</span>
              <span class="auto-step-pill">📦 5. Restocked</span>
            </div>

            <div style="margin-top: 0.75rem; font-size: 0.75rem; color: var(--text-muted); font-family: var(--font-mono); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem;">
              <span>${s.transferLog && s.transferLog.length > 0 ? s.transferLog[s.transferLog.length - 1] : 'Telemetry synchronized.'}</span>
              <span style="color: var(--canva-cyan); font-weight: 700;">Zero human typing required • Fully automated by LIFORA</span>
            </div>
          </div>
        </div>
      `;
    });

    container.innerHTML = html;

    // Update Crisis ticker banner & badge
    const tickerText = document.getElementById('crisis-ticker-text');
    if (tickerText) {
      tickerText.innerHTML = `🤖 <strong>${totalAlertCount} Hospital Shortages Being Resolved Autonomously:</strong> Apex Trauma (O- Blood), St. Jude (Pediatric Beds), Westside Clinic (Oxygen). Auto-reports sent to nearest neighbors.`;
    }

    const crisisTabBadge = document.getElementById('badge-crisis-num');
    if (crisisTabBadge) {
      crisisTabBadge.innerText = `${totalAlertCount} Auto-Aid Active`;
    }
  }

  function simulateNewCrisisAutonomous(event) {
    if (event) createWaveRipple(event);
    state.audio.playDispatch();

    const existingSim = DATA.facilityShortages.find(s => s.id === 'CRISIS-SIM-01');
    if (existingSim) {
      showToast('ℹ️ Live autonomous crisis simulation is already active on the grid!', 'info');
      const elem = document.getElementById('card-CRISIS-SIM-01');
      if (elem) elem.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

    const newCrisis = {
      id: "CRISIS-SIM-01",
      facilityId: "HOSP-05",
      facilityName: "South Suburban Trauma & Orthopedic Center",
      crisisType: "Mass Casualty Plasma & Burn Kit Depletion",
      category: "blood",
      item: "Fresh Frozen Plasma & Specialized Burn Grafts",
      currentStock: "0 Units (Depleted)",
      thresholdMin: "6 Units",
      severity: "CRITICAL",
      detectedTime: "Just Now (Real-Time Sensor Alert)",
      details: "Incoming 4-alarm chemical explosion triage casualties. Cold-storage RFID telemetry tripped: burn dressings and plasma exhausted (0 units remaining).",
      recommendedDonor: "Metro General Hospital & Regional Burn Unit",
      donorDistance: "1.6 km",
      donorAvailableStock: "14 Units Cryo-Plasma & 8 Advanced Burn Kits",
      donorContact: "+1 (800) 555-0242",
      suggestedAction: "LIFORA Autonomous Telemetry Engine triggered zero-input auto-mutual aid transfer to Metro General",
      status: "TRANSFER_EN_ROUTE",
      autoReportSent: true,
      autoReportTargetOrg: "Metro General Hospital & Regional Burn Unit",
      autoReportTelex: `[AUTONOMOUS CAD #MA-9099 ${timeStr}] CRITICAL BURN UNIT DEPLETION AT SOUTH SUBURBAN: Plasma stock reached 0. Telemetry engine auto-transmitted priority transfer report to nearest capable center: Metro General Hospital.`,
      neighborOrgResponse: `[CONFIRMED - METRO GENERAL CAD] Autonomous report verified & accepted. 6 units Plasma + 4 burn kits loaded into Rapid-Transfer Amb-102. Police Green Corridor escort unit PE-02 assigned. ETA: 4 mins.`,
      transferStatus: "EN_ROUTE",
      etaMinutes: 4,
      transferLog: [
        `[AUTO-ENGINE ${timeStr}] Cold storage sensor triggered 0-unit plasma warning at South Suburban.`,
        `[AUTO-REPORT ${timeStr}] Autonomous assistance report transmitted to Metro General Hospital (1.6 km).`,
        `[NEIGHBOR-ACK ${timeStr}] Metro General confirmed automated aid package dispatch.`
      ]
    };

    DATA.facilityShortages.unshift(newCrisis);

    // Step 1: Sensor alert toast
    showToast(`🚨 TELEMETRY ALERT: South Suburban Trauma Center facing Critical Plasma Shortage!`, 'critical');

    // Step 2: Auto-report notification
    setTimeout(() => {
      state.audio.playPing();
      showToast(`🤖 AUTONOMOUS ENGINE: Nearest neighbor identified (Metro General, 1.6km). Auto-report sent!`, 'info');
    }, 1200);

    // Step 3: Neighbor confirmation notification
    setTimeout(() => {
      state.audio.playAlert();
      showToast(`🤝 NEIGHBOR CONFIRMED: Metro General accepted report! Rapid courier en route via Green Corridor.`, 'success');
    }, 2600);

    // Add to task log
    state.taskLogs.unshift({
      time: timeStr,
      tag: 'AUTO-AID',
      text: `🤖 [AUTONOMOUS TELEMETRY] South Suburban shortage auto-routed to Metro General (1.6 km). Courier dispatched.`
    });

    // Also prepend to the CAD telemetry feed element if present
    const cadFeed = document.getElementById('autonomous-cad-telemetry-feed');
    if (cadFeed) {
      const newEntry = document.createElement('div');
      newEntry.style.cssText = 'background: rgba(244, 63, 94, 0.2); padding: 0.75rem 1rem; border-radius: var(--radius-sm); border-left: 3px solid #f43f5e;';
      newEntry.innerHTML = `
        <div style="color: #fca5a5; font-weight: 700; margin-bottom: 0.2rem;">[AUTONOMOUS CAD #MA-9099] • SOUTH SUBURBAN ➔ METRO GENERAL HOSPITAL (LIVE)</div>
        <div style="color: #cbd5e1;">Mass casualty plasma/burn kit depletion detected. Automated assistance report accepted. Rapid Courier Amb-102 en route under Police Green Corridor. (ETA: 4 min)</div>
      `;
      cadFeed.insertBefore(newEntry, cadFeed.firstChild);
    }

    renderFacilityShortages();
    renderTaskLogs();

    // Pulse new card
    setTimeout(() => {
      const card = document.getElementById('card-CRISIS-SIM-01');
      if (card) {
        card.scrollIntoView({ behavior: 'smooth', block: 'start' });
        card.style.boxShadow = '0 0 35px rgba(6, 182, 212, 0.8)';
      }
    }, 150);
  }

  function transmitMutualAidRequest(crisisId, event) {
    if (event) createWaveRipple(event);
    state.audio.playDispatch();

    const shortage = DATA.facilityShortages.find(s => s.id === crisisId);
    if (!shortage) return;

    shortage.status = 'TRANSFER_EN_ROUTE';
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    
    const logMsg = `[${timeStr}] Telex confirmed. ${shortage.recommendedDonor} authorized emergency transfer of ${shortage.item} to ${shortage.facilityName}. Green Corridor dispatched.`;
    if (!shortage.transferLog) shortage.transferLog = [];
    shortage.transferLog.push(logMsg);

    // If blood shortage, dynamically adjust blood inventory
    if (shortage.category === 'blood') {
      const redCross = DATA.bloodBanks.find(b => b.id === 'BLD-01');
      const apexBld = DATA.bloodBanks.find(b => b.id === 'BLD-02');
      if (redCross && apexBld) {
        redCross.inventory['O-'] = Math.max(1, redCross.inventory['O-'] - 2);
        apexBld.inventory['O-'] = apexBld.inventory['O-'] + 2;
      }
    }

    // Add task log entry
    state.taskLogs.unshift({
      time: timeStr,
      tag: 'MUTUAL-AID',
      text: `🤝 Inter-Facility Transfer: ${shortage.recommendedDonor} sending ${shortage.item} to ${shortage.facilityName} (${shortage.donorDistance} away)`
    });

    renderFacilityShortages();
    renderTaskLogs();
    renderResourceDirectory();

    showToast(`✅ Mutual Aid Message Transmitted! Transfer underway from ${shortage.recommendedDonor}`, 'success');
  }

  function openCrisisTab(event) {
    if (event) createWaveRipple(event);
    state.audio.playClick();

    switchSectorWithWave('organization-sector');

    setTimeout(() => {
      const crisisTab = document.getElementById('tab-crisis-btn');
      if (crisisTab) crisisTab.click();
      
      const pane = document.getElementById('tab-crisis-shortages');
      if (pane) {
        pane.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 380);
  }

  function handleCustomMutualAidMsg(event) {
    event.preventDefault();
    createWaveRipple(event);
    state.audio.playPing();

    const recipientElem = document.getElementById('ma-recipient');
    const urgencyElem = document.getElementById('ma-urgency');
    const notesElem = document.getElementById('ma-notes');

    const recipient = recipientElem ? recipientElem.value : 'ALL_HOSPITALS';
    const urgency = urgencyElem ? urgencyElem.value : 'CRITICAL_DIVERSION';
    const notes = notesElem ? notesElem.value : 'Emergency mutual aid broadcast';

    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

    state.taskLogs.unshift({
      time: timeStr,
      tag: 'MUTUAL-ALERT',
      text: `📡 [CAD-ALERT ${urgency}] Broadcast to ${recipient}: "${notes}"`
    });

    if (notesElem) notesElem.value = '';
    renderTaskLogs();

  }

  function renderSmartMatchingIncidents() {
    const container = document.getElementById('smart-incidents-list');
    if (!container) return;

    let html = '';
    let unmetCount = 0;

    DATA.incidents.forEach(inc => {
      const isCritical = inc.severity === 'CRITICAL';
      const isHigh = inc.severity === 'HIGH';
      const sevClass = isCritical ? 'critical' : (isHigh ? 'high' : '');

      let unmetHtml = '';
      if (inc.unfulfilledNeeds && inc.unfulfilledNeeds.length > 0) {
        unmetCount += inc.unfulfilledNeeds.length;
        unmetHtml = `
          <div class="unfulfilled-box">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
            <span>Unfulfilled Requirement: <strong>${inc.unfulfilledNeeds.join(', ')}</strong></span>
          </div>
        `;
      }

      const candidateAmb = DATA.ambulances.find(a => a.status === 'Available') || DATA.ambulances[0];
      let matchHtml = '';
      if (candidateAmb) {
        matchHtml = `
          <div class="match-recommendation">
            <div>
              <div style="font-weight: 700; color: #fff;">Smart Matched: ${candidateAmb.callSign} (${candidateAmb.type})</div>
              <div style="font-size: 0.76rem; color: var(--text-secondary);">Proximity ETA: <strong>${candidateAmb.etaMinutes} mins</strong> • Equipment: ACLS / Telemetry</div>
            </div>
            <div class="sector-pill-tag" style="background: rgba(6, 182, 212, 0.2); color: var(--canva-cyan); font-weight: 700;">98% MATCH</div>
          </div>
        `;
      }

      html += `
        <div class="smart-incident-card ${sevClass}">
          <div class="incident-card-top">
            <span class="incident-id-badge">${inc.id} • ${inc.reportedTime}</span>
            <span class="severity-pill ${sevClass}">${inc.severity}</span>
          </div>

          <h5 style="font-size: 1.1rem; margin-bottom: 0.35rem;">${inc.title}</h5>
          <div style="font-size: 0.78rem; color: var(--canva-cyan); margin-bottom: 0.4rem;">📍 ${inc.location}</div>
          <p style="font-size: 0.84rem; color: var(--text-secondary); line-height: 1.5; margin-bottom: 0.85rem;">${inc.description}</p>

          ${unmetHtml}
          ${matchHtml}

          <div style="display: flex; gap: 0.75rem;">
            <button type="button" class="btn-dispatch" onclick="window.LIFORA_APP.dispatchUnitToIncident('${inc.id}', '${candidateAmb.id}', event)">
              <span>⚡ Dispatch Smart Matched Unit</span>
            </button>
            <button type="button" class="btn-secondary" style="font-size: 0.82rem; padding: 0.5rem 0.95rem;" onclick="window.LIFORA_APP.focusOnMap(${inc.lat}, ${inc.lng}, '${inc.title}')">
              <span>Map Focus</span>
            </button>
          </div>
        </div>
      `;
    });

    container.innerHTML = html;

    const badge = document.getElementById('badge-unmet-num');
    if (badge) badge.innerText = unmetCount;
    const hudUnmet = document.getElementById('hud-unmet-count');
    if (hudUnmet) hudUnmet.innerText = `${unmetCount} Active`;
  }

  function renderReliabilityAuditor() {
    const tbody = document.getElementById('reliability-table-body');
    if (!tbody) return;

    let html = '';
    let staleCount = 0;

    const auditList = [
      ...DATA.hospitals.map(h => ({ id: h.id, name: h.name, type: 'Hospital / ER', mins: h.lastVerifiedMinutesAgo, score: h.reliabilityScore, by: h.verifiedBy })),
      ...DATA.bloodBanks.map(b => ({ id: b.id, name: b.name, type: 'Blood Bank', mins: b.lastVerifiedMinutesAgo, score: b.reliabilityScore, by: b.verifiedBy })),
      ...DATA.fireStations.map(f => ({ id: f.id, name: f.name, type: 'Fire Station', mins: f.lastVerifiedMinutesAgo, score: f.reliabilityScore, by: 'Station Chief' }))
    ];

    auditList.forEach(item => {
      const isStale = item.mins > 30;
      if (isStale) staleCount++;

      let statusColor = '#34d399';
      let statusText = `${item.mins}m ago`;
      if (item.mins > 45) {
        statusColor = '#f43f5e';
        statusText = `⚠️ Overdue (${item.mins}m)`;
      } else if (item.mins > 20) {
        statusColor = '#f59e0b';
        statusText = `${item.mins}m ago`;
      }

      html += `
        <tr>
          <td>
            <div style="font-weight: 700; color: #fff;">${item.name}</div>
            <div style="font-size: 0.72rem; color: var(--text-muted);">${item.by || 'Gateway Auto'}</div>
          </td>
          <td><span style="font-size: 0.76rem; color: var(--text-secondary);">${item.type}</span></td>
          <td><span class="mono" style="color: ${statusColor}; font-weight: 700;">${statusText}</span></td>
          <td><span class="mono" style="font-weight: 700;">${item.score}%</span></td>
          <td>
            <button type="button" class="btn-verify-ping" onclick="window.LIFORA_APP.verifyResource('${item.id}', event)">
              <span>↻ Re-Verify Ping</span>
            </button>
          </td>
        </tr>
      `;
    });

    tbody.innerHTML = html;

    const staleBadge = document.getElementById('badge-stale-num');
    if (staleBadge) staleBadge.innerText = `${staleCount} Stale`;
    const hudStale = document.getElementById('hud-stale-count');
    if (hudStale) hudStale.innerText = `${staleCount} Items`;
  }

  function renderTaskLogs() {
    const container = document.getElementById('task-feed-logs');
    if (!container) return;

    let html = '';
    state.taskLogs.forEach(log => {
      html += `
        <div style="display: flex; gap: 0.85rem; padding: 0.85rem 0; border-bottom: 1px solid var(--border-subtle); font-size: 0.84rem;">
          <div class="mono" style="color: var(--text-muted); font-size: 0.74rem; width: 68px; flex-shrink: 0;">${log.time}</div>
          <div>
            <span class="sector-pill-tag" style="background: rgba(255,255,255,0.08); font-size: 0.68rem; margin-bottom: 0.25rem;">${log.tag}</span>
            <div style="color: #cbd5e1; line-height: 1.45;">${log.text}</div>
          </div>
        </div>
      `;
    });
    container.innerHTML = html;
  }

  // --- ACTIONS: DISPATCH, VERIFY, BROADCAST ---
  function dispatchUnitToIncident(incidentId, unitId, event) {
    createWaveRipple(event);
    state.audio.playDispatch();

    const inc = DATA.incidents.find(i => i.id === incidentId);
    const amb = DATA.ambulances.find(a => a.id === unitId);

    if (inc && amb) {
      amb.status = 'En Route';
      amb.incidentAssigned = inc.id;

      inc.assignedUnits.push({
        id: amb.id,
        name: amb.callSign,
        type: amb.type,
        status: 'En Route (ETA 3 mins)'
      });

      if (inc.unfulfilledNeeds && inc.unfulfilledNeeds.length > 0) {
        inc.unfulfilledNeeds.shift();
      }

      inc.status = 'DISPATCHED';
      inc.citizenProgress = 65;

      const now = new Date();
      const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
      state.taskLogs.unshift({
        time: timeStr,
        tag: 'DISPATCH',
        text: `Smart-Matched ${amb.callSign} dispatched to ${inc.title} (Incident #${inc.id})`
      });

      state.activeIncidentForTracker = inc;

      renderAll();
      showToast(`Unit ${amb.callSign} dispatched to Incident #${inc.id}`, 'success');
      if (state.currentSector === 'organization-sector') {
        focusOnMap(amb.lat, amb.lng, `🚑 ${amb.callSign} En Route`);
      }
    }
  }

  function verifyResource(resourceId, event) {
    createWaveRipple(event);
    state.audio.playPing();

    const hosp = DATA.hospitals.find(h => h.id === resourceId);
    if (hosp) {
      hosp.lastVerifiedMinutesAgo = 1;
      hosp.reliabilityScore = 100;
      hosp.verifiedBy = 'Charge Nurse Direct Audio/RFID Ping';
    }

    const bld = DATA.bloodBanks.find(b => b.id === resourceId);
    if (bld) {
      bld.lastVerifiedMinutesAgo = 1;
      bld.reliabilityScore = 100;
      bld.verifiedBy = 'Smart Fridge RFID Auto-Telemetry';
    }

    const fire = DATA.fireStations.find(f => f.id === resourceId);
    if (fire) {
      fire.lastVerifiedMinutesAgo = 1;
      fire.reliabilityScore = 100;
    }

    renderReliabilityAuditor();
    renderResourceDirectory();
    renderMapMarkers();

    showToast(`Resource reliability verified: Freshness reset to 1m ago (100% confidence)`, 'success');
  }

  function focusOnMap(lat, lng, label) {
    switchSectorWithWave('organization-sector');

    setTimeout(() => {
      if (state.map) {
        state.map.setView([lat, lng], 15, { animate: true });
        for (let k in state.mapMarkers) {
          const m = state.mapMarkers[k];
          const mLat = m.getLatLng().lat;
          const mLng = m.getLatLng().lng;
          if (Math.abs(mLat - lat) < 0.0001 && Math.abs(mLng - lng) < 0.0001) {
            m.openPopup();
            break;
          }
        }
      }
    }, 380);
  }

  function selectIncidentForTracker(incidentId) {
    const inc = DATA.incidents.find(i => i.id === incidentId);
    if (inc) {
      state.activeIncidentForTracker = inc;
      renderCitizenTracker();
      renderConnectedAgencies();
      switchSectorWithWave('citizen-sector');
      showToast(`Loaded tracker for Incident #${inc.id}`, 'normal');
    }
  }

  function broadcastAlertPrompt(event) {
    createWaveRipple(event);
    state.audio.playAlert();
    switchSectorWithWave('organization-sector');
    setTimeout(() => {
      const broadcastTab = document.querySelector('.cmd-tab-link[data-target="tab-broadcast"]');
      if (broadcastTab) broadcastTab.click();
    }, 380);
  }

  function handleBroadcastSubmit(event) {
    event.preventDefault();
    createWaveRipple(event);
    state.audio.playAlert();

    const rad = document.getElementById('broadcast-radius').value;
    const msg = document.getElementById('broadcast-message').value;

    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    state.taskLogs.unshift({
      time: timeStr,
      tag: 'GEO-BROADCAST',
      text: `Civil Alert broadcast across ${rad}km radius: "${msg}"`
    });

    renderTaskLogs();
    showToast(`🚨 Geo-Fenced Alert Broadcasted to ${rad}km perimeter!`, 'alert');
    document.getElementById('broadcast-message').value = '';
  }

  // --- LIVE CITY SIMULATION ENGINE ---
  function toggleSimulation() {
    state.simulationActive = !state.simulationActive;
    const btn = document.getElementById('simulation-toggle-btn');
    const dot = document.getElementById('sim-pulse-dot');
    const lbl = document.getElementById('sim-toggle-label');

    if (state.simulationActive) {
      btn.classList.add('active');
      dot.style.background = '#10b981';
      dot.style.boxShadow = '0 0 10px #10b981';
      lbl.innerText = 'Simulation: Active';
      state.audio.playPing();
      showToast('Live Metropolitan City Simulation running', 'success');

      state.simulationTimer = setInterval(runSimulationTick, 5000);
    } else {
      btn.classList.remove('active');
      dot.style.background = 'var(--text-muted)';
      dot.style.boxShadow = 'none';
      lbl.innerText = 'Start Live Simulation';
      clearInterval(state.simulationTimer);
      showToast('Live Simulation paused', 'normal');
    }
  }

  function runSimulationTick() {
    const amb = DATA.ambulances[0];
    if (amb) {
      amb.lat += (Math.random() - 0.48) * 0.0015;
      amb.lng += (Math.random() - 0.48) * 0.0015;
      if (state.mapMarkers[`amb_${amb.id}`]) {
        state.mapMarkers[`amb_${amb.id}`].setLatLng([amb.lat, amb.lng]);
      }
    }

    if (state.activeIncidentForTracker) {
      if (state.activeIncidentForTracker.citizenProgress < 100) {
        state.activeIncidentForTracker.citizenProgress += 5;
        renderCitizenTracker();
      }
    }

    state.audio.playTone(1350, 'sine', 0.04, 0.02);
  }

  // --- MODALS ---
  function setupModals() {
    const sevOptions = document.querySelectorAll('#rep-severity-selector .sev-option');
    sevOptions.forEach(opt => {
      opt.addEventListener('click', (e) => {
        createWaveRipple(e);
        state.audio.playClick();
        sevOptions.forEach(o => o.classList.remove('selected'));
        opt.classList.add('selected');
        document.getElementById('rep-severity').value = opt.getAttribute('data-sev');
      });
    });
  }

  function openReportModal(category, event) {
    if (event) createWaveRipple(event);
    state.audio.playClick();
    const modal = document.getElementById('report-incident-modal');
    if (modal) {
      modal.classList.add('show');
      modal.setAttribute('aria-hidden', 'false');
    }
    if (category) {
      const select = document.getElementById('rep-category');
      if (select) select.value = category;
    }
  }

  function closeReportModal() {
    state.audio.playClick();
    const modal = document.getElementById('report-incident-modal');
    if (modal) {
      modal.classList.remove('show');
      modal.setAttribute('aria-hidden', 'true');
    }
  }

  function useCurrentLocation() {
    state.audio.playPing();
    const locInput = document.getElementById('rep-location');
    locInput.value = 'GPS: 28.6275° N, 77.2185° E (Connaught Sector 3)';
    showToast('Current GPS Coordinates captured via device telemetry', 'success');
  }

  function handleReportSubmit(e) {
    e.preventDefault();
    createWaveRipple(e);
    state.audio.playAlert();

    const category = document.getElementById('rep-category').value;
    const severity = document.getElementById('rep-severity').value;
    const title = document.getElementById('rep-title').value;
    const location = document.getElementById('rep-location').value;
    const victims = parseInt(document.getElementById('rep-victims').value, 10) || 1;
    const phone = document.getElementById('rep-phone').value;
    const description = document.getElementById('rep-description').value || 'Citizen emergency dispatch request.';

    const newId = `INC-${Math.floor(1000 + Math.random() * 9000)}`;

    const newIncident = {
      id: newId,
      type: `${category.toUpperCase()} Emergency`,
      category: category,
      title: title,
      location: location,
      lat: 28.6139 + (Math.random() - 0.5) * 0.03,
      lng: 77.2090 + (Math.random() - 0.5) * 0.03,
      severity: severity,
      reportedTime: 'Just now',
      timestamp: Date.now(),
      reporter: `Citizen (${phone})`,
      victims: victims,
      description: description,
      requiredResources: [category === 'medical' ? 'ACLS Ambulance' : (category === 'fire' ? 'Fire Engine' : 'Rapid Interceptor')],
      assignedUnits: [],
      unfulfilledNeeds: [`Immediate ${category} responder unit`],
      status: 'REPORTED',
      matchedHospital: 'Apex Central Trauma Center',
      citizenProgress: 25
    };

    DATA.incidents.unshift(newIncident);
    state.activeIncidentForTracker = newIncident;

    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    state.taskLogs.unshift({
      time: timeStr,
      tag: 'NEW-SOS',
      text: `🚨 ${title} reported at ${location} (Ticket: ${newId})`
    });

    closeReportModal();
    renderAll();

    state.currentSector = 'citizen-sector';
    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;

    showToast(`🚨 Ticket LF-${newId.replace('INC-', '')} Registered! Organizations notified.`, 'alert');
  }

  function useCurrentLocationInline(event) {
    if (event) createWaveRipple(event);
    state.audio.playPing();
    const locInput = document.getElementById('inline-rep-location');
    if (locInput) {
      locInput.value = 'GPS: 28.6310° N, 77.2220° E (Central Interchange, Ring Rd)';
    }
    showToast('Device GPS Telemetry locked: Central Interchange', 'success');
  }

  function handleInlineReportSubmit(e) {
    e.preventDefault();
    createWaveRipple(e);
    state.audio.playAlert();

    const category = document.getElementById('inline-rep-category').value;
    const severity = document.getElementById('inline-rep-severity').value;
    const title = document.getElementById('inline-rep-title').value;
    const location = document.getElementById('inline-rep-location').value;
    const victims = parseInt(document.getElementById('inline-rep-victims').value, 10) || 1;
    const phone = document.getElementById('inline-rep-phone').value;
    const description = document.getElementById('inline-rep-description').value || 'Citizen emergency dispatch request submitted via LIFORA Portal.';

    const newId = `INC-${Math.floor(1000 + Math.random() * 9000)}`;

    const connectedAgencies = [
      {
        id: 'AGY-HOSP',
        type: 'Trauma Hospital',
        name: 'Apex Central Trauma & Multi-Specialty Hospital',
        role: 'ER Triage & Trauma Resuscitation Standby',
        status: 'ACKNOWLEDGED',
        actionTaken: 'Emergency surgical bay reserved with direct blood access.',
        eta: 'Ready on Arrival',
        icon: '🏥',
        phone: '+1 (800) 555-0191'
      },
      {
        id: 'AGY-EMS',
        type: 'Paramedic EMS',
        name: 'Medic-Alpha 1 (ACLS Rapid Unit)',
        role: 'Advanced Life Support & Telemetry Uplink',
        status: 'EN_ROUTE',
        actionTaken: 'Dispatched immediately with full paramedic crew.',
        eta: '2.5 mins (0.9 km)',
        icon: '🚑',
        phone: '+1 (800) 555-AMB1'
      },
      {
        id: 'AGY-POL',
        type: 'Highway Police',
        name: 'Metro Patrol Interceptor 08',
        role: 'Intersection Green Wave & Perimeter Securing',
        status: 'DISPATCHED',
        actionTaken: 'Clearing traffic corridor along route to accelerate ambulance response.',
        eta: '3 mins (1.2 km)',
        icon: '🚓',
        phone: '+1 (800) 555-100'
      },
      {
        id: 'AGY-FIRE',
        type: 'Fire Rescue Squad',
        name: 'Central Fire Rescue Unit 2',
        role: category === 'fire' ? 'Primary Fire Suppression & Containment' : 'Specialized Extrication & Scene Stabilization',
        status: 'DISPATCHED',
        actionTaken: category === 'fire' ? 'Pumper engine & high-reach ladder rolling out with full crew' : 'Heavy extrication gear and thermal sensors deployed',
        eta: '4 mins (1.6 km)',
        icon: '🚒',
        phone: '+1 (800) 555-FIRE1'
      }
    ];

    const newIncident = {
      id: newId,
      type: `${category.toUpperCase()} Emergency`,
      category: category,
      title: title,
      location: location,
      lat: 28.6139 + (Math.random() - 0.5) * 0.03,
      lng: 77.2090 + (Math.random() - 0.5) * 0.03,
      severity: severity,
      reportedTime: 'Just now',
      timestamp: Date.now(),
      reporter: `Citizen (${phone})`,
      victims: victims,
      description: description,
      requiredResources: [
        category === 'medical' ? 'ACLS Ambulance' : (category === 'fire' ? 'Fire Engine' : 'Rapid Interceptor'),
        'Trauma Bay Standby',
        'Green Corridor Escort'
      ],
      assignedUnits: [
        { id: 'AMB-101', name: 'Medic-Alpha 1', type: 'ACLS Ambulance', status: 'En Route (ETA 2.5 mins)' }
      ],
      unfulfilledNeeds: [],
      status: 'DISPATCHED',
      matchedHospital: 'Apex Central Trauma Center (0.9 km)',
      citizenProgress: 65,
      connectedAgencies: connectedAgencies
    };

    DATA.incidents.unshift(newIncident);
    state.activeIncidentForTracker = newIncident;

    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    state.taskLogs.unshift({
      time: timeStr,
      tag: 'CITIZEN-SOS',
      text: `🚨 Citizen reported #${newId}: "${title}" at ${location}. Coordinated dispatch sent to Trauma Hospital, EMS, Police & Fire.`
    });

    document.getElementById('inline-rep-title').value = '';
    document.getElementById('inline-rep-description').value = '';

    renderAll();

    showToast(`🚨 Incident Logged! 4 Organizations Notified & Acting!`, 'alert');

    // Keep citizen firmly at top of citizen-sector with zero scrolling away
    state.currentSector = 'citizen-sector';
    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;

    const respBox = document.getElementById('citizen-agency-response-box');
    if (respBox) {
      respBox.style.boxShadow = '0 0 35px rgba(6, 182, 212, 0.7)';
      respBox.style.borderColor = 'var(--canva-cyan)';
      setTimeout(() => {
        respBox.style.boxShadow = '';
        respBox.style.borderColor = '';
      }, 2500);
    }

    setTimeout(() => {
      state.audio.playDispatch();
    }, 400);
  }

  // --- TOAST NOTIFICATIONS ---
  function showToast(message, type = 'normal') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast-message ${type}`;

    let icon = '⚡';
    if (type === 'alert') icon = '🚨';
    if (type === 'success') icon = '✓';

    toast.innerHTML = `
      <span>${icon}</span>
      <div style="flex: 1;">${message}</div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4200);
  }

  function renderAll() {
    renderCitizenTracker();
    renderConnectedAgencies();
    renderFacilityShortages();
    renderResourceDirectory();
    renderSmartMatchingIncidents();
    renderReliabilityAuditor();
    renderTaskLogs();
    renderMapMarkers();

    const activeCount = DATA.incidents.length;
    const headerCount = document.getElementById('header-active-count');
    if (headerCount) headerCount.innerText = activeCount;
  }

  // --- EXPOSE GLOBAL API ---
  window.LIFORA_APP = {
    triggerKineticEntrance,
    openPortalGateway,
    switchSectorWithWave,
    createWaveRipple,
    triggerWaveTransition,
    quickSOS,
    openReportModal,
    closeReportModal,
    useCurrentLocation,
    useCurrentLocationInline,
    handleReportSubmit,
    handleInlineReportSubmit,
    acknowledgeAgency,
    renderConnectedAgencies,
    renderFacilityShortages,
    simulateNewCrisisAutonomous,
    transmitMutualAidRequest,
    openCrisisTab,
    handleCustomMutualAidMsg,
    handleBroadcastSubmit,
    broadcastAlertPrompt,
    dispatchUnitToIncident,
    verifyResource,
    focusOnMap,
    selectIncidentForTracker,
    toggleSimulation,
    showToast
  };

  window.LIFEGRID_APP = window.LIFORA_APP;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
